import{W as n}from"./index-DNvyajg_.js";import"./vendor-B_wc6cnX.js";import"./supabase-wWQuBM6K.js";class t extends n{async show(e){}async hide(e){}}export{t as SplashScreenWeb};
